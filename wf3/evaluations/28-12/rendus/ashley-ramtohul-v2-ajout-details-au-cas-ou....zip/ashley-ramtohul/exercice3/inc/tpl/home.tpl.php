<?php
# Le fichier doit être inclus
if( ! session_id() ) exit;
?>

<p>Bienvenue sur notre merveilleux site de Films !</p>
<p>Fonctionnalités :</p>
<ul>
    <li>Lister les films</li>
    <li>Ajouter de nouveaux films</li>
    <li>Afficher les détails d'un films</li>
</ul>